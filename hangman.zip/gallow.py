def construct_gallow():
    gallow = []
    gallow.append("          \n          \n          \n          \n          \n   _ _    ")
    gallow.append("          \n  |       \n  |       \n  |       \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |       \n  |       \n  |       \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/      \n  |       \n  |       \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |       \n  |       \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |  O    \n  |       \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |  O    \n  |  |    \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |  O    \n  | /|    \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |  O    \n  | /|\   \n  |       \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |  O    \n  | /|\   \n  | /     \n  |_ _    ")
    gallow.append("  ____    \n  |/ |    \n  |  O    \n  | /|\   \n  | / \   \n  |_ _    ")
    return gallow
